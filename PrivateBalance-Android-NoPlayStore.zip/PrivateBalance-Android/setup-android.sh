#!/usr/bin/env bash
set -euo pipefail

# Installs a minimal Android SDK in Codespaces if ANDROID_HOME is not already configured.
SDK_DIR="${ANDROID_HOME:-$HOME/android-sdk}"
CMDLINE_DIR="$SDK_DIR/cmdline-tools/latest"

if command -v sdkmanager >/dev/null 2>&1; then
  echo "sdkmanager already available."
else
  mkdir -p "$SDK_DIR/cmdline-tools"
  if [ ! -x "$CMDLINE_DIR/bin/sdkmanager" ]; then
    TMP="$HOME/android-cmdline-tools.zip"
    echo "Downloading Android command-line tools..."
    curl -L --fail -o "$TMP" https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    rm -rf "$SDK_DIR/cmdline-tools/latest" "$SDK_DIR/cmdline-tools/cmdline-tools"
    unzip -q "$TMP" -d "$SDK_DIR/cmdline-tools"
    mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$CMDLINE_DIR"
    rm -f "$TMP"
  fi
  export ANDROID_HOME="$SDK_DIR"
  export PATH="$CMDLINE_DIR/bin:$SDK_DIR/platform-tools:$SDK_DIR/cmdline-tools/tools/bin:$PATH"
fi

export ANDROID_HOME="${ANDROID_HOME:-$SDK_DIR}"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

echo
printf 'Android SDK ready. ANDROID_HOME=%s\n' "$ANDROID_HOME"
