# PRIVATE BALANCE — Android APK

Project Android WebView untuk aplikasi PRIVATE BALANCE.

## Tanpa Play Store

APK dibuat sebagai **signed release APK** dan dapat dipasang langsung di Android. Tidak perlu Google Play Store.

### Cara paling mudah: GitHub Actions

1. Upload folder project ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build PRIVATE BALANCE APK**.
4. Klik **Run workflow**.
5. Setelah selesai, buka hasil workflow dan download artifact **PRIVATE-BALANCE-APK**.
6. Extract artifact dan ambil `app-release.apk`.
7. Kirim APK ke HP dan install langsung.

GitHub Actions hanya dipakai untuk proses build; aplikasi tidak dipublikasikan ke Play Store.

## Codespaces

Di Codespace:

```bash
bash setup-android.sh
gradle assembleRelease \
  -PRELEASE_STORE_FILE="$PWD/private-balance-release.jks" \
  -PRELEASE_STORE_PASSWORD=changeit \
  -PRELEASE_KEY_ALIAS=privatebalance \
  -PRELEASE_KEY_PASSWORD=changeit
```

APK:

```text
app/build/outputs/apk/release/app-release.apk
```

## Instalasi langsung

Android mungkin meminta izin untuk memasang aplikasi dari sumber yang tidak dikenal. Itu merupakan pemeriksaan keamanan Android dan berbeda dari Play Store.

Tidak ada cara yang sah untuk menjamin Play Protect tidak pernah menampilkan peringatan pada APK yang didistribusikan langsung. Jangan gunakan teknik untuk mem-bypass pemeriksaan keamanan Android.

## Catatan signing

Untuk versi berikutnya, gunakan **keystore yang sama** agar Android mengenali update sebagai aplikasi yang sama. Jangan commit file `.jks` ke repository publik.
