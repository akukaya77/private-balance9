# Private Balance WebView app: no custom shrinker rules required.
