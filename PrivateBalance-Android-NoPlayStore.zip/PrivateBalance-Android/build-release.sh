#!/usr/bin/env bash
set -euo pipefail

if [ ! -d "${ANDROID_HOME:-$HOME/android-sdk}" ]; then
  echo "ANDROID_HOME is not set. Run ./setup-android.sh first."
  exit 1
fi

export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

if [ ! -x ./gradlew ]; then
  if command -v gradle >/dev/null 2>&1; then
    gradle wrapper --gradle-version 8.7
  else
    echo "Gradle is not installed. Run this inside a Codespace with Gradle, or install Gradle 8.7."
    exit 1
  fi
fi

KEYSTORE="$PWD/private-balance-release.jks"
if [ ! -f "$KEYSTORE" ]; then
  echo "Creating local release keystore..."
  keytool -genkeypair -v -keystore "$KEYSTORE" -alias privatebalance -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass changeit -keypass changeit \
    -dname "CN=PRIVATE BALANCE, OU=App, O=Private Balance, L=Medan, ST=North Sumatra, C=ID"
fi

./gradlew assembleRelease \
  -PRELEASE_STORE_FILE="$KEYSTORE" \
  -PRELEASE_STORE_PASSWORD=changeit \
  -PRELEASE_KEY_ALIAS=privatebalance \
  -PRELEASE_KEY_PASSWORD=changeit

echo
printf 'APK: %s\n' "$PWD/app/build/outputs/apk/release/app-release.apk"
